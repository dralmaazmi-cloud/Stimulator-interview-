import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import healthHandler from '../api/health.js';
import evaluateHandler from '../api/evaluate.js';
import { getQuestionContext, sampleAnswerTexts } from '../api/_lib/data.js';
import { buildEvaluationPrompt } from '../api/_lib/prompts.js';
import { calculateScore, weightsForTesting } from '../api/_lib/scoring.js';
import { ngramSimilarity, normalizeArabic, sanitizeEvaluation, shapeErrors, verifyEvidence } from '../api/_lib/validation.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const project = path.resolve(here, '..');
const read = relative => fs.readFileSync(path.join(project, relative));
const json = relative => JSON.parse(read(relative).toString('utf8'));

function mockResponse() {
  return {
    statusCode: 200,
    headers: {},
    payload: undefined,
    setHeader(key, value) { this.headers[key.toLowerCase()] = value; },
    end(value) { this.payload = value ? JSON.parse(value) : undefined; }
  };
}

const requiredFiles = [
  'api/health.js', 'api/evaluate.js', 'api/transcribe.js', 'api/followup.js', 'api/self-intro.js',
  'api/_lib/provider.js', 'api/_lib/schemas.js', 'api/_lib/prompts.js', 'api/_lib/validation.js',
  'api/_lib/scoring.js', 'api/_lib/rate-limit.js', 'api/_lib/usage.js',
  'dist/js/evaluate-client.js', 'dist/js/recorder.js', 'dist/js/report.js', 'dist/js/simulation.js',
  'dist/js/sessions.js'
];
requiredFiles.forEach(file => assert.ok(fs.existsSync(path.join(project, file)), `Missing ${file}`));

const referenceBytes = read('dist/data/reference.json');
const manifest = json('dist/data/derived/manifest.json');
const biasSuite = json('tests/answers/bias-suite.json');
assert.equal(crypto.createHash('sha256').update(referenceBytes).digest('hex'), manifest.reference_sha256,
  'Phase 2 must not alter the source reference');
assert.ok(biasSuite.fixtures.length >= 55, 'Live bias suite must contain at least 55 cases');
assert.equal(biasSuite.counts.copied_reference, 10);
assert.equal(biasSuite.counts.hypothetical_drift, 5);
assert.equal(biasSuite.counts.off_competency, 5);

const context = getQuestionContext('C1-B1');
const sourceSamples = sampleAnswerTexts(context.question);
const prompt = buildEvaluationPrompt(context, 'شرحت الخطة بنفسي ثم طلبت من كل عضو أن يلخص دوره.', []);
assert.match(prompt, /C1-B1/);
assert.match(prompt, /إجابة المستخدم المصححة/);
assert.ok(sourceSamples.length);
sourceSamples.forEach(sample => assert.ok(!prompt.includes(sample), 'Evaluation prompt must never contain a source sample answer'));

const selfIntroContext = getQuestionContext('SELF-INTRO');
assert.equal(selfIntroContext.question.rubric_mode, 'self_intro');
assert.ok(selfIntroContext.rubricSections.some(section => section.number === '6.3'));

const userText = 'في بداية المشروع كان الفريق متأخرًا. كانت مهمتي إعادة توزيع العمل. أنا عقدت اجتماعًا ووزعت الأدوار بنفسي. اكتمل المشروع في الموعد. تعلمت أن المتابعة المبكرة تمنع التأخير.';
const rawReport = {
  question_id: 'C1-B1',
  rubric_mode: 'star_l',
  elements: {
    situation: { present: true, quote: 'في بداية المشروع كان الفريق متأخرًا' },
    task: { present: true, quote: 'كانت مهمتي إعادة توزيع العمل' },
    action: { present: true, quote: 'أنا عقدت اجتماعًا ووزعت الأدوار بنفسي' },
    result: { present: true, quote: 'اكتمل المشروع في الموعد' },
    learning: { present: true, quote: 'تعلمت أن المتابعة المبكرة تمنع التأخير' }
  },
  criteria: [
    { key: 'context', score: 4, evidence: ['في بداية المشروع كان الفريق متأخرًا'], justification: 'سياق واضح.' },
    { key: 'personal_role_or_options', score: 4, evidence: ['كانت مهمتي إعادة توزيع العمل'], justification: 'الدور واضح.' },
    { key: 'action_or_plan', score: 4, evidence: ['أنا عقدت اجتماعًا ووزعت الأدوار بنفسي'], justification: 'إجراء شخصي.' },
    { key: 'result_or_effect', score: 4, evidence: ['اكتمل المشروع في الموعد'], justification: 'نتيجة واضحة.' },
    { key: 'learning', score: 4, evidence: ['تعلمت أن المتابعة المبكرة تمنع التأخير'], justification: 'تعلم واضح.' },
    { key: 'competency_evidence', score: 4, evidence: ['اقتباس غير موجود في الإجابة'], justification: 'يجب رفض هذا الدليل.' }
  ],
  expected_points_coverage: context.question.expected_points.points.map(item => ({
    point: item.text,
    covered: false,
    quote: null
  })),
  behaviours_observed: { supporting: [], negative: [] },
  mission_command_indicators: [],
  flags: [],
  strengths: ['وضوح الموقف'],
  missing: ['مؤشر رقمي أدق'],
  next_actions: ['أضف مؤشرًا قابلًا للقياس.'],
  follow_up_questions: ['ما المؤشر الذي استخدمته لقياس النتيجة؟']
};

assert.deepEqual(shapeErrors(rawReport, 'C1-B1', 'star_l'), []);
const sanitized = sanitizeEvaluation(structuredClone(rawReport), context);
const verified = verifyEvidence(sanitized, userText);
assert.equal(verified.report.criteria.find(item => item.key === 'competency_evidence').score, 2,
  'A criterion without a literal verified quote must be capped at 2');
assert.equal(verified.report.criteria.find(item => item.key === 'competency_evidence').evidence.length, 0);
assert.equal(verified.failed, 1);

const score = calculateScore(verified.report, 'behavioural', userText);
assert.equal(score.final_score, 74);
assert.equal(score.classification, 'قوية');
assert.ok(score.action_ratio > 0);
assert.equal(Object.values(weightsForTesting().behavioural).reduce((sum, weight) => sum + weight, 0), 100);
assert.equal(Object.values(weightsForTesting().scenario).reduce((sum, weight) => sum + weight, 0), 100);
assert.equal(Object.values(weightsForTesting().general).reduce((sum, weight) => sum + weight, 0), 100);
assert.equal(Object.values(weightsForTesting().self_intro).reduce((sum, weight) => sum + weight, 0), 100);

assert.equal(normalizeArabic('أُجريت مُقابلة ناجحة'), normalizeArabic('اجريت مقابله ناجحه'));
assert.equal(ngramSimilarity('هذا نص مطابق تمامًا في كل الكلمات المهمة', 'هذا نص مطابق تمامًا في كل الكلمات المهمة', 4), 1);
assert.ok(ngramSimilarity('كلمات مختلفة تمامًا هنا', 'هذا نص آخر لا يشبه الأول', 4) < 0.35);

const malformed = structuredClone(rawReport);
malformed.criteria.pop();
assert.ok(shapeErrors(malformed, 'C1-B1', 'star_l').includes('criteria'));
const duplicate = structuredClone(rawReport);
duplicate.criteria[5].key = 'context';
assert.ok(shapeErrors(duplicate, 'C1-B1', 'star_l').includes('criteria.keys'));

const clientText = fs.readdirSync(path.join(project, 'dist/js'))
  .map(file => read(`dist/js/${file}`).toString('utf8')).join('\n');
assert.doesNotMatch(clientText, /GEMINI_API_KEY|GOOGLE_API_KEY|AIza[0-9A-Za-z_-]{20,}/,
  'Provider credentials or environment variable names must not appear in the client');
assert.match(read('api/_lib/provider.js').toString('utf8'), /process\.env\.GEMINI_API_KEY/);
assert.match(read('api/_lib/provider.js').toString('utf8'), /'audio\/mp4': 'audio\/m4a'/,
  'iOS audio MIME must be mapped to a provider-supported MIME');
assert.match(read('dist/sw.js').toString('utf8'), /url\.pathname\.startsWith\('\/api\/'\)/,
  'Service worker must never cache API responses');
assert.match(read('dist/js/recorder.js').toString('utf8'), /MAX_SECONDS = 120/);
assert.match(read('dist/js/recorder.js').toString('utf8'), /MAX_BYTES = 4 \* 1024 \* 1024/);
assert.match(read('dist/js/simulation.js').toString('utf8'), /راجع التفريغ وصححه/);
assert.match(read('dist/js/simulation.js').toString('utf8'), /SELF-INTRO/);
assert.match(read('dist/js/report.js').toString('utf8'), /قارن بنموذج الدليل/);

const savedGemini = process.env.GEMINI_API_KEY;
const savedGoogle = process.env.GOOGLE_API_KEY;
delete process.env.GEMINI_API_KEY;
delete process.env.GOOGLE_API_KEY;
try {
  const healthRes = mockResponse();
  await healthHandler({ method: 'GET', headers: {} }, healthRes);
  assert.equal(healthRes.statusCode, 200);
  assert.equal(healthRes.payload.phase, 2);
  assert.equal(healthRes.payload.ai.configured, false);

  const evaluateRes = mockResponse();
  await evaluateHandler({
    method: 'POST',
    headers: { 'x-client-id': 'phase2-test' },
    socket: { remoteAddress: '127.0.0.1' },
    body: { question_id: 'C1-B1', answer: userText }
  }, evaluateRes);
  assert.equal(evaluateRes.statusCode, 503);
  assert.equal(evaluateRes.payload.code, 'AI_NOT_CONFIGURED');
  assert.doesNotMatch(evaluateRes.payload.error, /Gemini|جيميناي/i);
} finally {
  if (savedGemini === undefined) delete process.env.GEMINI_API_KEY;
  else process.env.GEMINI_API_KEY = savedGemini;
  if (savedGoogle === undefined) delete process.env.GOOGLE_API_KEY;
  else process.env.GOOGLE_API_KEY = savedGoogle;
}

const originalFetch = globalThis.fetch;
process.env.GEMINI_API_KEY = 'phase2-test-key';
try {
  globalThis.fetch = async (url, options) => {
    assert.equal(String(url), 'https://generativelanguage.googleapis.com/v1beta/interactions');
    const providerBody = JSON.parse(options.body);
    assert.equal(providerBody.model, 'gemini-3.8-flash');
    assert.equal(providerBody.response_format.mime_type, 'application/json');
    sourceSamples.forEach(sample => assert.ok(!providerBody.input.includes(sample), 'Provider request leaked a source model answer'));
    return new Response(JSON.stringify({
      output_text: JSON.stringify(rawReport),
      usage_metadata: { input_token_count: 100, output_token_count: 50 }
    }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  const livePathRes = mockResponse();
  await evaluateHandler({
    method: 'POST',
    headers: { 'x-client-id': 'phase2-mocked-success' },
    socket: { remoteAddress: '127.0.0.1' },
    body: { question_id: 'C1-B1', answer: userText }
  }, livePathRes);
  assert.equal(livePathRes.statusCode, 200);
  assert.equal(livePathRes.payload.report.final_score, 74);
  assert.equal(livePathRes.payload.report.verification.rejected_quotes, 1);
  assert.equal(livePathRes.payload.meta.reference_sha256, manifest.reference_sha256);
} finally {
  globalThis.fetch = originalFetch;
  if (savedGemini === undefined) delete process.env.GEMINI_API_KEY;
  else process.env.GEMINI_API_KEY = savedGemini;
}

console.log('PASS phase 2 engine: prompt isolation, schema checks, quote verification, scoring, API safety.');
