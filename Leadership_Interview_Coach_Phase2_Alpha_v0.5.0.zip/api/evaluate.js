import crypto from 'node:crypto';
import { clientKey, handleApiError, httpError, methodAllowed, readJson, sendJson } from './_lib/http.js';
import { enforceRateLimit } from './_lib/rate-limit.js';
import { complete } from './_lib/provider.js';
import { getQuestionContext, sampleAnswerTexts } from './_lib/data.js';
import { evaluationSchema } from './_lib/schemas.js';
import { buildEvaluationPrompt } from './_lib/prompts.js';
import { ngramSimilarity, sanitizeEvaluation, shapeErrors, verifyEvidence } from './_lib/validation.js';
import { calculateScore } from './_lib/scoring.js';
import { recordUsage } from './_lib/usage.js';

const PROMPT_VERSION = 'phase2-evaluation-1.0';
const RUBRIC_VERSION = 'reference-rubric-1.0';

function cleanFollowups(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 2).map(item => ({
    question: String(item?.question || '').trim().slice(0, 500),
    answer: String(item?.answer || '').trim().slice(0, 6000)
  })).filter(item => item.question && item.answer);
}

async function runEvaluation(context, answer, followups, model) {
  const response = await complete(buildEvaluationPrompt(context, answer, followups), evaluationSchema, { model });
  const errors = shapeErrors(response.data, context.question.id, context.question.rubric_mode);
  if (errors.length) {
    const error = httpError(502, `Schema validation failed: ${errors.join(', ')}`, 'AI_SCHEMA_FAILED');
    error.usage = response.usage;
    throw error;
  }
  const sanitized = sanitizeEvaluation(response.data, context);
  const combinedText = [answer, ...followups.map(item => item.answer)].join('\n');
  const verified = verifyEvidence(sanitized, combinedText);
  return { ...verified, usage: response.usage, combinedText };
}

export default async function handler(req, res) {
  const started = Date.now();
  if (!methodAllowed(req, res, ['POST'])) return;
  try {
    enforceRateLimit(`evaluate:${clientKey(req)}`, { limit: 40, windowMs: 60 * 60 * 1000 });
    const body = await readJson(req, 160_000);
    const questionId = String(body.question_id || '').trim();
    const answer = String(body.answer || '').trim();
    const followups = cleanFollowups(body.followups);
    if (!questionId) throw httpError(400, 'معرّف السؤال مطلوب.');
    if (answer.length < 5) throw httpError(400, 'الإجابة قصيرة جدًا للتقييم.');
    if (answer.length > 12_000) throw httpError(413, 'الإجابة أطول من الحد المسموح.');

    const context = getQuestionContext(questionId);
    if (questionId === 'SELF-INTRO') {
      const targetDuration = Number(body.target_duration) === 120 ? 120 : 60;
      const spokenDuration = Math.max(0, Math.min(180, Number(body.spoken_duration) || 0));
      const estimatedDuration = Math.round(answer.split(/\s+/).filter(Boolean).length / 115 * 60);
      context.question = {
        ...context.question,
        target_duration: targetDuration,
        answer_duration_seconds: spokenDuration || estimatedDuration,
        duration_source: spokenDuration ? 'recording' : 'word_count_estimate'
      };
    }
    const retryModel = process.env.GEMINI_RETRY_MODEL || process.env.GEMINI_MODEL;
    let evaluated;
    let firstError;
    try {
      evaluated = await runEvaluation(context, answer, followups);
      if (evaluated.failureRate > 0.3) {
        firstError = httpError(502, 'Too many unverified quotes.', 'AI_EVIDENCE_FAILED');
        firstError.usage = evaluated.usage;
        evaluated = await runEvaluation(context, answer, followups, retryModel);
      }
    } catch (error) {
      if (!['AI_INVALID_JSON', 'AI_SCHEMA_FAILED'].includes(error?.code)) throw error;
      firstError = error;
      evaluated = await runEvaluation(context, answer, followups, retryModel);
    }

    const referenceSimilarity = Math.max(0, ...sampleAnswerTexts(context.question).map(sample => ngramSimilarity(answer, sample, 4)));
    const nearReferenceModel = referenceSimilarity >= 0.35;
    if (nearReferenceModel) {
      const competencyCriterion = evaluated.report.criteria.find(item => item.key === 'competency_evidence');
      if (competencyCriterion) competencyCriterion.score = Math.min(3, competencyCriterion.score);
    }
    const trusted = evaluated.failureRate <= 0.3;
    const score = trusted
      ? calculateScore(evaluated.report, context.question.type, evaluated.combinedText)
      : { final_score: null, classification: 'غير موثوق', action_ratio: null, weights_version: 'phase2-1.0' };
    const report = {
      ...evaluated.report,
      ...score,
      trusted,
      reliability_label: trusted ? 'موثّق بالاقتباسات' : 'تقييم غير موثوق — لا توجد درجة رقمية',
      near_reference_model: nearReferenceModel,
      reference_similarity: Number(referenceSimilarity.toFixed(3)),
      verification: {
        checked_quotes: evaluated.checked,
        rejected_quotes: evaluated.failed,
        failure_rate: Number(evaluated.failureRate.toFixed(3)),
        retried: Boolean(firstError)
      }
    };
    const askedFollowups = new Set(followups.map(item => item.question));
    report.follow_up_questions = report.follow_up_questions.filter(question => !askedFollowups.has(question)).slice(0, 2);

    const usage = {
      input_tokens: (firstError?.usage?.input_tokens || 0) + (evaluated.usage?.input_tokens || 0),
      output_tokens: (firstError?.usage?.output_tokens || 0) + (evaluated.usage?.output_tokens || 0)
    };
    recordUsage({
      type: 'evaluate',
      duration_ms: Date.now() - started,
      ...usage,
      validation: trusted ? 'passed' : 'untrusted',
      success: true
    });
    sendJson(res, 200, {
      report,
      meta: {
        request_id: crypto.randomUUID(),
        prompt_version: PROMPT_VERSION,
        rubric_version: RUBRIC_VERSION,
        reference_sha256: context.referenceSha256
      }
    });
  } catch (error) {
    recordUsage({ type: 'evaluate', duration_ms: Date.now() - started, validation: error?.code || 'failed', success: false });
    handleApiError(res, error);
  }
}
