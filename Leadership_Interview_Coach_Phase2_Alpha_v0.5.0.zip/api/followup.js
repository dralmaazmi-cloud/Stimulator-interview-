import { clientKey, handleApiError, httpError, methodAllowed, readJson, sendJson } from './_lib/http.js';
import { enforceRateLimit } from './_lib/rate-limit.js';
import { complete } from './_lib/provider.js';
import { getQuestionContext } from './_lib/data.js';
import { followUpSchema } from './_lib/schemas.js';
import { buildFollowUpPrompt } from './_lib/prompts.js';
import { recordUsage } from './_lib/usage.js';

export default async function handler(req, res) {
  const started = Date.now();
  if (!methodAllowed(req, res, ['POST'])) return;
  try {
    enforceRateLimit(`followup:${clientKey(req)}`, { limit: 40, windowMs: 60 * 60 * 1000 });
    const body = await readJson(req, 120_000);
    const answer = String(body.answer || '').trim();
    if (answer.length < 5) throw httpError(400, 'الإجابة مطلوبة.');
    const context = getQuestionContext(body.question_id);
    const result = await complete(buildFollowUpPrompt(context, answer, body.report || {}), followUpSchema);
    const questions = Array.isArray(result.data?.questions)
      ? result.data.questions.map(item => String(item || '').trim()).filter(Boolean).slice(0, 2)
      : [];
    const reasons = Array.isArray(result.data?.reasons)
      ? result.data.reasons.map(item => String(item || '').trim()).filter(Boolean).slice(0, questions.length)
      : [];
    recordUsage({ type: 'followup', duration_ms: Date.now() - started, ...result.usage, validation: 'passed', success: true });
    sendJson(res, 200, { questions, reasons });
  } catch (error) {
    recordUsage({ type: 'followup', duration_ms: Date.now() - started, validation: error?.code || 'failed', success: false });
    handleApiError(res, error);
  }
}
