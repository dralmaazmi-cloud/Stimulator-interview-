const DEFAULT_JSON_LIMIT = 160_000;

export function applyApiHeaders(res) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('X-Content-Type-Options', 'nosniff');
}

export function sendJson(res, status, payload) {
  applyApiHeaders(res);
  res.statusCode = status;
  res.end(JSON.stringify(payload));
}

export function methodAllowed(req, res, allowed) {
  if (allowed.includes(req.method)) return true;
  res.setHeader('Allow', allowed.join(', '));
  sendJson(res, 405, { error: 'الطريقة غير مسموحة.' });
  return false;
}

export async function readBuffer(req, maximumBytes) {
  if (Buffer.isBuffer(req.body)) {
    if (req.body.length > maximumBytes) throw httpError(413, 'حجم الطلب أكبر من الحد المسموح.');
    return Buffer.from(req.body);
  }
  if (typeof req.body === 'string') {
    const body = Buffer.from(req.body);
    if (body.length > maximumBytes) throw httpError(413, 'حجم الطلب أكبر من الحد المسموح.');
    return body;
  }

  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maximumBytes) throw httpError(413, 'حجم الطلب أكبر من الحد المسموح.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

export async function readJson(req, maximumBytes = DEFAULT_JSON_LIMIT) {
  if (req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body)) return req.body;
  const buffer = await readBuffer(req, maximumBytes);
  if (!buffer.length) throw httpError(400, 'الطلب فارغ.');
  try {
    return JSON.parse(buffer.toString('utf8'));
  } catch {
    throw httpError(400, 'صيغة الطلب غير صالحة.');
  }
}

export function httpError(status, message, code = '') {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

export function handleApiError(res, error) {
  const status = Number(error?.status) || 500;
  const safeMessage = status >= 500
    ? (error?.code === 'AI_NOT_CONFIGURED'
      ? 'خدمة المحاكاة غير مهيأة بعد. أضف مفتاح الذكاء الاصطناعي في إعدادات الخادم.'
      : 'تعذّر إكمال الطلب الآن. حاول مرة أخرى بعد قليل.')
    : error.message;
  if (status >= 500) console.error('[api]', error?.code || error?.name, error?.message);
  sendJson(res, status, { error: safeMessage, code: error?.code || undefined });
}

export function clientKey(req) {
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  const client = String(req.headers['x-client-id'] || '').slice(0, 80);
  return `${forwarded || req.socket?.remoteAddress || 'unknown'}:${client || 'anonymous'}`;
}
