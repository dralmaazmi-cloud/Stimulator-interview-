import { httpError } from './http.js';

const INTERACTIONS_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/interactions';
const DEFAULT_MODEL = 'gemini-3.8-flash';
// يسمح بمحاولتين داخل حد وظيفة Vercel البالغ 60 ثانية مع هامش للتحقق والاستجابة.
const REQUEST_TIMEOUT_MS = 28_000;

function apiKey() {
  return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '';
}

export function providerConfigured() {
  return Boolean(apiKey());
}

export function providerInfo() {
  return {
    configured: providerConfigured(),
    mode: providerConfigured() ? 'live' : 'unconfigured'
  };
}

function modelId(override, kind = 'evaluation') {
  if (override) return override;
  if (kind === 'transcription') return process.env.GEMINI_TRANSCRIBE_MODEL || process.env.GEMINI_MODEL || DEFAULT_MODEL;
  return process.env.GEMINI_MODEL || DEFAULT_MODEL;
}

async function callInteractions(body) {
  const key = apiKey();
  if (!key) throw httpError(503, 'Gemini API is not configured.', 'AI_NOT_CONFIGURED');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  let response;
  try {
    response = await fetch(INTERACTIONS_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': key
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });
  } catch (error) {
    if (error?.name === 'AbortError') throw httpError(504, 'انتهت مهلة مزود الذكاء الاصطناعي.', 'AI_TIMEOUT');
    throw httpError(502, 'تعذر الاتصال بمزود الذكاء الاصطناعي.', 'AI_CONNECTION_FAILED');
  } finally {
    clearTimeout(timeout);
  }

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload?.error?.message || `Provider HTTP ${response.status}`;
    const error = httpError(response.status === 429 ? 429 : 502, detail, 'AI_PROVIDER_ERROR');
    error.providerStatus = response.status;
    throw error;
  }
  return payload;
}

function outputText(payload) {
  const direct = payload?.output_text
    ?? payload?.interaction?.output_text
    ?? payload?.interaction?.outputText
    ?? payload?.output?.text;
  if (typeof direct === 'string' && direct.trim()) return direct.trim();

  const nested = payload?.candidates?.[0]?.content?.parts
    ?.map(part => part.text || '')
    .join('')
    .trim();
  if (nested) return nested;
  throw httpError(502, 'عاد المزود باستجابة فارغة.', 'AI_EMPTY_RESPONSE');
}

function usage(payload) {
  const source = payload?.usage_metadata || payload?.usageMetadata || payload?.interaction?.usage || {};
  return {
    input_tokens: Number(source.input_token_count || source.promptTokenCount || source.inputTokens) || 0,
    output_tokens: Number(source.output_token_count || source.candidatesTokenCount || source.outputTokens) || 0
  };
}

export async function complete(prompt, schema, options = {}) {
  const payload = await callInteractions({
    model: modelId(options.model),
    input: prompt,
    response_format: {
      type: 'text',
      mime_type: 'application/json',
      schema
    }
  });
  const text = outputText(payload);
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw httpError(502, 'مخرجات التقييم ليست JSON صالحًا.', 'AI_INVALID_JSON');
  }
  return { data, usage: usage(payload), model: modelId(options.model) };
}

export async function transcribe(audio, mime) {
  const providerMime = ({
    'audio/mp4': 'audio/m4a',
    'audio/x-m4a': 'audio/m4a'
  })[mime] || mime;
  const payload = await callInteractions({
    model: modelId(null, 'transcription'),
    input: [
      {
        type: 'text',
        text: 'فرّغ الكلام العربي حرفيًا فقط. احتفظ باللهجة والكلمات الإنجليزية كما نُطقت. لا تصحح اللغة، لا تلخص، لا تضف ولا تكمل. ضع [غير واضح] لأي مقطع غير مفهوم. أخرج نص التفريغ فقط دون مقدمة أو ملاحظات.'
      },
      { type: 'audio', data: audio.toString('base64'), mime_type: providerMime }
    ]
  });
  return { transcript: outputText(payload), usage: usage(payload), model: modelId(null, 'transcription') };
}
