import { chromium, devices } from 'playwright';
import fs from 'node:fs';
const OUT = process.env.OUT || new URL('./shots', import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });
const BASE = process.env.BASE || 'http://localhost:4173';
const log = (k, v) => console.log(`[${k}] ${v}`);
const ANSWER = 'في بداية المشروع كان الفريق متأخرًا عن الجدول. كانت مهمتي إعادة توزيع العمل بين الأعضاء. أنا عقدت اجتماعًا ووزعت الأدوار بنفسي وتابعت التنفيذ يوميًا. اكتمل المشروع في الموعد المحدد. تعلمت أن المتابعة المبكرة تمنع التأخير.';

async function newPage(opts = {}) {
  const browser = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'] });
  const context = await browser.newContext({ ...devices['iPhone 14'], locale: 'ar-AE', permissions: ['microphone'], ...opts });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  // v0.5.1 item 6: starting a new session over an in-progress one asks for confirmation; accept it and log it.
  page.on('dialog', d => { log('dialog', `${d.type()}: ${d.message().slice(0, 80)}`); d.accept(); });
  return { browser, context, page, errors };
}
const text = async (page, sel) => (await page.locator(sel).first().innerText().catch(() => '')).replace(/\s+/g, ' ');
const shot = (page, name) => page.screenshot({ path: `${OUT}/j-${name}.png`, fullPage: true });
const gotoHash = async (page, url) => { await page.goto(url.split('#')[0] + '#/home'); await page.waitForTimeout(250); await page.goto(url); await page.waitForTimeout(250); };

// ---------- Journey 1: single question, text answer, follow-up, finish, saved, print ----------
{
  const { browser, page, errors } = await newPage();
  await page.goto(BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.waitForTimeout(500);
  log('J1 health notice', await text(page, '.ai-health-host'));
  const modes = await page.locator('.simulation-mode-card').allInnerTexts();
  log('J1 modes', modes.map(m => m.replace(/\n/g, ' / ')).join(' || '));
  log('J1 default mode', await page.locator('.simulation-mode-card.selected strong').innerText());
  log('J1 default answer mode', await page.locator('.simulation-answer-switch button.active').innerText());
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  log('J1 question header', await text(page, '.page-head h1'));
  const qid = await text(page, '.ai-question-card .question-id');
  const qtext = await text(page, '.ai-question-card h2');
  log('J1 question', `${qid} :: ${qtext.slice(0, 80)}`);
  log('J1 progress bar', await page.locator('.simulation-progress').getAttribute('aria-valuenow'));
  // submit empty
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForTimeout(300);
  log('J1 empty submit toast', await text(page, '.toast'));
  await page.locator('textarea.simulation-answer-input').fill(ANSWER);
  await shot(page, '1-question');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  log('J1 scrollY after report (item 8)', String(await page.evaluate(() => window.scrollY)));
  log('J1 final-score text', await text(page, '.final-score'));
  log('J1 report hero', await text(page, '.score-hero'));
  log('J1 trust notice', await text(page, '.evaluation-report .notice'));
  log('J1 report sections', (await page.locator('.evaluation-report h3').allInnerTexts()).join(' | '));
  log('J1 action buttons', (await page.locator('.report-actions .button').allInnerTexts()).join(' | '));
  const bodyText = await page.locator('body').innerText();
  log('J1 null/undefined in report', String((bodyText.match(/\b(null|undefined|NaN)\b/g) || []).length));
  await shot(page, '1-report');
  // compare with guide
  await page.locator('button:has-text("قارن بنموذج الدليل")').click();
  await page.waitForTimeout(300);
  log('J1 compare dialog open', String(await page.locator('#app-dialog').evaluate(d => d.open)) + ' :: ' + (await text(page, '#dialog-content')).slice(0, 120));
  await shot(page, '1-compare');
  await page.locator('#app-dialog button[value=cancel]').click();
  // follow-up
  await page.locator('button:has-text("الإجابة عن سؤال المتابعة")').click();
  await page.waitForSelector('.followup-question-card');
  log('J1 followup card', await text(page, '.followup-question-card'));
  await shot(page, '1-followup');
  await page.locator('textarea.simulation-answer-input').fill('المؤشر كان نسبة الإنجاز في الوقت المحدد وبلغت تسعين بالمئة.');
  await page.locator('button:has-text("إعادة التقييم مع المتابعة")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  log('J1 followup merged in report', String((await text(page, '.transcript-review-card')).includes('تسعين بالمئة')));
  log('J1 followup button still shown after 1 followup?', String(await page.locator('button:has-text("الإجابة عن سؤال المتابعة")').count()));
  await page.locator('button:has-text("إنهاء وعرض الملخص")').click();
  await page.waitForSelector('.session-summary');
  log('J1 summary', (await text(page, '.session-summary-hero')));
  log('J1 summary buttons', (await page.locator('.session-summary .button').allInnerTexts()).join(' | '));
  await shot(page, '1-summary');
  // saved sessions
  await page.goto(BASE + '/#/sessions');
  await page.waitForTimeout(500);
  log('J1 sessions list', (await text(page, '.session-history-list')).slice(0, 150));
  await page.locator('.session-history-card').first().click();
  await page.waitForTimeout(500);
  log('J1 saved session view headings', (await page.locator('h1,h2,h3').allInnerTexts()).join(' | '));
  log('J1 saved view shows criteria/quotes?', String(await page.locator('.criteria-list, .evidence-quotes').count()));
  await shot(page, '1-saved-session');
  // print css — closed saved reports must open on beforeprint and show criteria
  await page.evaluate(() => window.dispatchEvent(new Event('beforeprint')));
  await page.emulateMedia({ media: 'print' });
  log('J1 print: saved report criteria visible (item 7)', String(await page.locator('details.saved-report .criteria-list').evaluateAll(nodes => nodes.filter(node => node.getClientRects().length > 0).length)));
  await page.screenshot({ path: `${OUT}/j-1-print.png`, fullPage: true });
  const hiddenInPrint = await page.evaluate(() => ({ nav: getComputedStyle(document.querySelector('.bottom-nav')).display, header: getComputedStyle(document.querySelector('.app-header')).display, noPrint: getComputedStyle(document.querySelector('.no-print') || document.body).display }));
  log('J1 print media hides chrome', JSON.stringify(hiddenInPrint));
  await page.emulateMedia({ media: 'screen' });
  // second session for comparison
  await gotoHash(page, BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER + ' نحن كفريق أنجزنا ذلك.');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  log('J1b flags shown', await text(page, '.flags-card'));
  await page.locator('button:has-text("إنهاء وعرض الملخص")').click();
  await page.waitForSelector('.session-summary');
  log('J1b comparison with previous', await text(page, '.session-comparison'));
  await shot(page, '1b-summary-compare');
  // save & exit mid-session: is it resumable?
  await gotoHash(page, BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill('مسودة غير مرسلة');
  await page.locator('button:has-text("حفظ والخروج إلى الرئيسية")').click();
  await page.waitForTimeout(500);
  const resumeOnHome = await page.locator('body').innerText();
  log('J1c after save&exit: home mentions resume?', String(/استئناف|متابعة الجلسة|جلسة غير مكتملة/.test(resumeOnHome)));
  await page.goto(BASE + '/#/sessions');
  await page.waitForTimeout(400);
  log('J1c sessions page lists in-progress session?', String(/غير مكتملة|قيد التنفيذ|استئناف/.test(await page.locator('body').innerText())));
  const stored = await page.evaluate(() => new Promise(resolve => { const r = indexedDB.open('leadership-interview-coach'); r.onsuccess = () => { const tx = r.result.transaction('sessions'); const g = tx.objectStore('sessions').getAll(); g.onsuccess = () => resolve(g.result.map(s => ({ status: s.status, draft: s.draft_answer, n: (s.responses || []).length }))); }; }));
  log('J1c IndexedDB sessions', JSON.stringify(stored));
  // ---- item 6: resume → same question, same draft → submit → report → finish → completed, no in_progress copy left
  const pendingQid = await page.evaluate(() => new Promise(resolve => { const r = indexedDB.open('leadership-interview-coach'); r.onsuccess = () => { const tx = r.result.transaction('sessions'); const g = tx.objectStore('sessions').getAll(); g.onsuccess = () => resolve(g.result.find(s => s.status === 'in_progress')?.question_ids?.[0] || ''); }; }));
  await gotoHash(page, BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  log('J1d resume card shown on simulation setup', String(await page.locator('.resume-card').count()) + ' :: ' + (await text(page, '.resume-card')).slice(0, 80));
  await page.locator('.resume-card button:has-text("استئناف")').click();
  await page.waitForSelector('.ai-question-card');
  log('J1d resumed same question?', String((await text(page, '.ai-question-card .question-id')) === pendingQid) + ` (${pendingQid})`);
  log('J1d draft restored?', String((await page.locator('textarea.simulation-answer-input').inputValue()) === 'مسودة غير مرسلة'));
  await page.locator('textarea.simulation-answer-input').fill(ANSWER + ' NOFOLLOWUP');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  await page.locator('button:has-text("إنهاء وعرض الملخص")').click();
  await page.waitForSelector('.session-summary');
  const afterResume = await page.evaluate(() => new Promise(resolve => { const r = indexedDB.open('leadership-interview-coach'); r.onsuccess = () => { const tx = r.result.transaction('sessions'); const g = tx.objectStore('sessions').getAll(); g.onsuccess = () => resolve({ completed: g.result.filter(s => s.status === 'completed').length, in_progress: g.result.filter(s => s.status === 'in_progress').length, drafts: g.result.filter(s => s.draft_answer).length }); }; }));
  log('J1d after finish: sessions by status (item 6)', JSON.stringify(afterResume));
  await page.goto(BASE + '/#/home'); await page.waitForTimeout(400);
  log('J1d home resume card gone after finish', String(await page.locator('.resume-session-card').count()));
  log('J1 page errors', JSON.stringify(errors));
  await browser.close();
}

// ---------- Journey 2: voice answer (fake mic) ----------
{
  const { browser, page, errors } = await newPage();
  await page.goto(BASE + '/#/simulation?answer=voice');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.voice-answer-panel');
  log('J2 voice panel', (await text(page, '.voice-answer-panel')).slice(0, 200));
  log('J2 textarea hidden before recording', String(await page.locator('textarea.simulation-answer-input').isHidden()));
  // start without consent
  await page.locator('.record-start').click();
  await page.waitForTimeout(300);
  log('J2 start without consent → toast', await text(page, '.toast'));
  await page.locator('.privacy-consent input').check();
  await page.locator('.record-start').click();
  await page.waitForTimeout(3500);
  log('J2 recording state', await text(page, '.recording-state') + ' clock=' + await text(page, '.recording-clock'));
  await shot(page, '2-recording');
  await page.locator('.record-stop').click();
  await page.waitForSelector('textarea.simulation-answer-input:visible', { timeout: 20000 });
  await page.waitForTimeout(500);
  const transcript = await page.locator('textarea.simulation-answer-input').inputValue();
  log('J2 transcript in editable textarea', transcript.slice(0, 80));
  log('J2 state after transcription', await text(page, '.recording-state'));
  log('J2 evaluation auto-started?', String(await page.locator('.evaluation-report').count() > 0));
  const calls = await (await fetch(BASE + '/__calls')).json();
  const tr = calls.filter(c => c.kind === 'transcribe').at(-1);
  log('J2 provider transcribe call', JSON.stringify(tr));
  await shot(page, '2-transcript');
  // edit transcript then submit
  await page.locator('textarea.simulation-answer-input').fill(transcript + ' وأضفت كلمة مصححة يدويًا.');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  log('J2 report uses corrected text', String((await text(page, '.transcript-review-card')).includes('مصححة يدويًا')));
  log('J2 page errors', JSON.stringify(errors));
  await browser.close();
}

// ---------- Journey 2b (item 14): transcription fails (provider 429 server) → resend same recording succeeds without re-recording ----------
{
  const { browser, page, errors } = await newPage();
  await page.goto('http://localhost:4176/#/simulation?answer=voice');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.voice-answer-panel');
  await page.locator('.privacy-consent input').check();
  await page.locator('.record-start').click();
  await page.waitForTimeout(2500);
  await page.locator('.record-stop').click();
  await page.waitForSelector('.record-resend:visible', { timeout: 20000 });
  log('J2b transcription failure message', (await text(page, '.voice-answer-panel .notice')).slice(0, 120));
  log('J2b resend button visible after failure', String(await page.locator('.record-resend').isVisible()));
  log('J2b textarea empty before resend', String((await page.locator('textarea.simulation-answer-input').inputValue()) === ''));
  // reroute the next transcribe call to the healthy server (simulates the provider recovering)
  let rerouted = 0;
  await page.route('**/api/transcribe', async route => {
    rerouted += 1;
    const request = route.request();
    const response = await fetch(BASE + '/api/transcribe', { method: 'POST', headers: { 'Content-Type': request.headers()['content-type'], 'X-Audio-Duration': request.headers()['x-audio-duration'], 'X-Client-Id': 'j2b' }, body: request.postDataBuffer() });
    await route.fulfill({ status: response.status, contentType: 'application/json', body: await response.text() });
  });
  await page.locator('.record-resend').click();
  await page.waitForSelector('textarea.simulation-answer-input:visible', { timeout: 20000 });
  await page.waitForFunction(() => document.querySelector('textarea.simulation-answer-input').value.length > 10, null, { timeout: 20000 }).catch(() => {});
  log('J2b resend succeeded without re-recording', String(rerouted === 1 && (await page.locator('textarea.simulation-answer-input').inputValue()).length > 10) + ` rerouted=${rerouted}`);
  log('J2b resend button hidden after success', String(await page.locator('.record-resend').isHidden()));
  log('J2b page errors', JSON.stringify(errors.filter(e => !/429|Failed to load resource/.test(e))));
  await browser.close();
}

// ---------- Journey 3: offline after first load (SW) ----------
{
  const { browser, context, page, errors } = await newPage();
  await page.goto(BASE + '/#/home');
  await page.waitForSelector('.home-hero');
  await page.waitForFunction(() => navigator.serviceWorker?.controller != null, null, { timeout: 15000 }).catch(() => log('J3', 'SW controller not ready'));
  await page.waitForTimeout(2500);
  const cached = await page.evaluate(async () => { const keys = await caches.keys(); const c = await caches.open(keys[0]); return { keys, count: (await c.keys()).length }; });
  log('J3 SW caches', JSON.stringify(cached));
  await context.setOffline(true);
  await page.goto(BASE + '/#/learn/U1').catch(e => log('J3 nav offline err', e.message));
  await page.waitForTimeout(1200);
  log('J3 offline learn U1 h1', await text(page, 'h1'));
  await page.goto(BASE + '/#/bank/C1-B1');
  await page.waitForTimeout(800);
  log('J3 offline bank C1-B1 h2', await text(page, '.question-detail-text'));
  await page.goto(BASE + '/#/self-intro');
  await page.waitForTimeout(800);
  log('J3 offline self-intro h1', await text(page, 'h1'));
  await page.goto(BASE + '/#/simulation');
  await page.waitForTimeout(1500);
  log('J3 offline simulation notice', await text(page, '.ai-health-host'));
  log('J3 offline start button enabled?', String(await page.locator('.simulation-start').isEnabled()));
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER);
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForTimeout(2500);
  log('J3 offline submit error', await text(page, '.evaluation-status'));
  log('J3 offline answer preserved', String((await page.locator('textarea.simulation-answer-input').inputValue()) === ANSWER));
  await shot(page, '3-offline-sim');
  await context.setOffline(false);
  log('J3 page errors', JSON.stringify(errors.slice(0, 5)));
  await browser.close();
}

// ---------- Journey 4: unconfigured key (port 4175) ----------
{
  const { browser, page } = await newPage();
  await page.goto('http://localhost:4175/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.waitForTimeout(600);
  log('J4 unconfigured notice', await text(page, '.ai-health-host'));
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER);
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForTimeout(1500);
  log('J4 unconfigured submit error', await text(page, '.evaluation-status'));
  await shot(page, '4-unconfigured');
  await browser.close();
}

// ---------- Journey 5: provider 429 leak (4176), bad quotes (untrusted), invalid JSON ----------
{
  const { browser, page } = await newPage();
  await gotoHash(page, 'http://localhost:4176/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER);
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForTimeout(1500);
  log('J5 provider-429 message shown to user', await text(page, '.evaluation-status'));
  await shot(page, '5-provider-429');
  await gotoHash(page, BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER + ' BADQUOTES');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForSelector('.evaluation-report', { timeout: 20000 });
  log('J5 untrusted report hero', await text(page, '.score-hero') + ' :: ' + await text(page, '.evaluation-report .notice'));
  await shot(page, '5-untrusted');
  await gotoHash(page, BASE + '/#/simulation');
  await page.waitForSelector('.simulation-start');
  await page.locator('.simulation-start').click();
  await page.waitForSelector('.ai-question-card');
  await page.locator('textarea.simulation-answer-input').fill(ANSWER + ' BADJSON');
  await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
  await page.waitForTimeout(2000);
  log('J5 invalid JSON message shown to user', await text(page, '.evaluation-status'));
  log('J5 answer preserved after error', String((await page.locator('textarea.simulation-answer-input').inputValue()).startsWith(ANSWER)));
  await browser.close();
}

// ---------- Journey 6: realistic + extended + mission modes, self-intro included ----------
{
  const { browser, page } = await newPage();
  for (const [mode, scope] of [['realistic', ''], ['extended', ''], ['extended', 'mission']]) {
    await gotoHash(page, BASE + `/#/simulation?mode=${mode}${scope ? '&competency=' + scope : ''}`);
    await page.waitForSelector('.simulation-start');
    await page.waitForTimeout(300);
    if (mode !== 'single') await page.locator('.simulation-intro-options input[type=checkbox]').check();
    await page.locator('.simulation-start').click();
    await page.waitForTimeout(600);
    log(`J6 ${mode}/${scope || 'random'} first screen`, await text(page, '.page-head h1'));
    await page.locator('textarea.simulation-answer-input').fill('أنا مدير فريق العمليات. بدأت مسيرتي مشرف عمليات ثم تدرجت إلى إدارة وحدة. من أبرز ما حققته خفض زمن الإنجاز. وأتطلع مستقبلًا إلى توسيع أثر التحسين.');
    await page.locator('button:has-text("تقييم تقديم الذات")').click();
    await page.waitForSelector('.evaluation-report', { timeout: 20000 });
    log(`J6 ${mode} self-intro report`, await text(page, '.score-hero'));
    await page.locator('button:has-text("ابدأ أسئلة المقابلة")').click();
    await page.waitForSelector('.ai-question-card');
    const ids = [];
    for (let i = 0; i < 6; i += 1) {
      ids.push(await text(page, '.ai-question-card .question-id'));
      await page.locator('textarea.simulation-answer-input').fill(ANSWER + ' NOFOLLOWUP');
      await page.locator('button:has-text("إرسال الإجابة للتقييم")').click();
      await page.waitForSelector('.evaluation-report', { timeout: 20000 });
      const next = page.locator('button:has-text("السؤال التالي")');
      if (await next.count()) await next.click(); else { await page.locator('button:has-text("إنهاء وعرض الملخص")').click(); break; }
      await page.waitForSelector('.ai-question-card');
      if (i === 0) log(`J6 ${mode} scrollY after drawQuestion (item 8)`, String(await page.evaluate(() => window.scrollY)));
    }
    await page.waitForSelector('.session-summary');
    log(`J6 ${mode}/${scope || 'random'} question ids`, ids.join(','));
    log(`J6 ${mode} summary`, (await text(page, '.session-summary-hero')));
    await shot(page, `6-${mode}-${scope || 'random'}-summary`);
  }
  await browser.close();
}

// ---------- Journey 7: self-intro builder local + AI improve ----------
{
  const { browser, page, context } = await newPage();
  await page.goto(BASE + '/#/self-intro');
  await page.waitForSelector('.intro-builder-card');
  await page.locator('button:has-text("بناء تقديم الذات")').click();
  await page.waitForTimeout(300);
  log('J7 missing fields toast', await text(page, '.toast'));
  const vals = { 0: 'قائد عمليات', 1: 'بكالوريوس إدارة', 3: 'مشرف عمليات', 4: 'الإشراف ثم إدارة وحدة ثم قيادة الفريق الحالي', 5: 'مدير فريق العمليات', 8: 'خفض زمن إنجاز المعاملات بنسبة عشرين بالمئة', 10: 'توسيع أثر التحسين ورفع جودة الخدمة' };
  const areas = page.locator('.intro-question textarea');
  for (const [i, v] of Object.entries(vals)) await areas.nth(Number(i)).fill(v);
  await page.locator('button:has-text("بناء تقديم الذات")').click();
  await page.waitForTimeout(400);
  const draft1 = await page.locator('.intro-result-text').first().inputValue();
  log('J7 draft', draft1.slice(0, 160));
  log('J7 metrics', await text(page, '.intro-metrics') + ' :: ' + (await text(page, '.intro-result .notice')));
  await page.locator('button:has-text("صياغة بديلة")').click();
  await page.waitForTimeout(300);
  const draft2 = await page.locator('.intro-result-text').first().inputValue();
  log('J7 alternative differs', String(draft1 !== draft2));
  // manual edit then leave and come back — is edit kept?
  await page.locator('.intro-result-text').first().fill(draft2 + ' تعديل يدوي.');
  await page.goto(BASE + '/#/home'); await page.waitForTimeout(300);
  await page.goto(BASE + '/#/self-intro'); await page.waitForTimeout(500);
  const afterReload = await page.locator('.intro-result-text').first().inputValue().catch(() => '');
  log('J7 manual edit persisted after leaving page?', String(afterReload.includes('تعديل يدوي')) + ` (result visible=${!(await page.locator('.intro-result').isHidden())})`);
  // regenerate and improve with AI
  await page.locator('button:has-text("بناء تقديم الذات")').click();
  await page.waitForTimeout(300);
  await page.locator('button:has-text("تحسين لغوي بالذكاء الاصطناعي")').click();
  await page.waitForSelector('.ai-intro-candidate textarea', { timeout: 15000 });
  log('J7 AI candidate', (await text(page, '.ai-intro-candidate')).slice(0, 160));
  const before = await page.locator('.intro-result-text').first().inputValue();
  log('J7 original untouched before approval', String(!before.includes('نسخة محسّنة')));
  await page.locator('button:has-text("اعتماد النسخة")').click();
  await page.waitForTimeout(300);
  log('J7 replaced after approval', String((await page.locator('.intro-result-text').first().inputValue()).includes('نسخة محسّنة')));
  await shot(page, '7-self-intro');
  // offline improve
  await context.setOffline(true);
  await page.locator('button:has-text("تحسين لغوي بالذكاء الاصطناعي")').click();
  await page.waitForTimeout(1500);
  log('J7 offline improve message', await text(page, '.ai-intro-candidate'));
  await browser.close();
}

// ---------- Journey 8: settings delete all data ----------
{
  const { browser, page } = await newPage();
  await page.goto(BASE + '/#/bank/C1-B1');
  await page.waitForTimeout(400);
  await page.locator('button:has-text("حفظ السؤال")').click();
  await page.goto(BASE + '/#/settings');
  await page.waitForTimeout(400);
  await page.locator('button:has-text("حذف كل بياناتي المحلية")').click();
  await page.waitForTimeout(600);
  const left = await page.evaluate(() => Object.keys(localStorage).filter(k => k.startsWith('lic:')));
  log('J8 localStorage lic:* keys after delete', JSON.stringify(left));
  await browser.close();
}
fs.writeFileSync(`${OUT}/journeys-done.txt`, 'ok');
